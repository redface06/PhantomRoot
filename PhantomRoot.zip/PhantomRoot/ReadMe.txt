Welcome to PhantomRoot Project.

** Before you continue its important to extract all the files from the .zip folder to the desktop and then open it **

Hello my name is RedFace and i was born in Greece and now i live in the UK for about 14 years.
Since childhood i was obsessed with hacking and programming. So thats why for the last 1 year i am making this project called PhantomRoot for you!

PhantomRoot is a multi tool for discord - telegram and not only.
Be careful dont use it for unethical reasons.

**to open the program close the antivirus **

To start just open the builder.exe and it will automatically install every requirement you need and once installed it will open.

Thank you

@redface 